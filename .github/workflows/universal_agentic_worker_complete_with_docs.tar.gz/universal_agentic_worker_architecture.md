# Universal Agentic Worker Architecture

## Goal

To design a universal, fully agentic AI worker CLI tool that combines the robust patterns of Deep SSnaHke (persistent state, caching, parallel processing, daemon mode) with advanced multi-turn LLM interactions, multi-provider API support (OpenAI, Copilot free mode, local LLMs, user-provided APIs), GitHub/GitLab Actions integration, and unrestricted tool execution capabilities (file operations, Git operations, shell commands, external API calls).

## Core Principles

1.  **Modularity and Extensibility**: Components should be loosely coupled, allowing for easy swapping of LLM providers, tool implementations, and persistence layers.
2.  **Observability**: Comprehensive, structured logging for all agent activities, LLM calls, and tool executions.
3.  **Resilience**: Graceful error handling, retry mechanisms, and persistent state to recover from interruptions.
4.  **Configurability**: All key parameters should be configurable via environment variables and CLI arguments.
5.  **Safety**: Dry-run modes and explicit confirmation for destructive actions.
6.  **Agentic Autonomy**: The agent should be capable of independent decision-making, planning, and execution based on its goals and available tools.

## Architectural Components

### 1. `AgentConfig` (Configuration Management)

-   **Purpose**: Centralized management of all agent configurations, loaded from environment variables, CLI arguments, and a potential config file.
-   **Inspiration**: Deep SSnaHke's extensive use of environment variables (`ROOTS`, `INTERVAL`, `DRY_RUN`).
-   **Key Attributes**: LLM provider settings (API keys, base URLs, model names), state directory, cache TTL, parallel job counts, default tools, GitHub/GitLab token, etc.

### 2. `Logger` (Observability)

-   **Purpose**: Structured JSON-lines logging for all agent events.
-   **Inspiration**: Deep SSnaHke's `TRAIL.log`.
-   **Features**: Logs agent lifecycle events, LLM interactions (prompts, responses, token counts), tool dispatches (name, arguments, duration, results), cache hits/misses, and errors. Supports different log levels.

### 3. `StateManager` (Persistent State)

-   **Purpose**: Manages the agent's persistent state, including conversation history, active tasks, and tool outputs.
-   **Inspiration**: Deep SSnaHke's `STATE_DIR`, `INDEX.tsv`, `PREV_INDEX`, `DUPES.tsv`.
-   **Implementation**: Uses a file-based JSON store (e.g., `state.json`) for simplicity and portability. Could be extended to support databases for larger-scale state management.
-   **Features**: Atomic writes, versioning (optional), and checkpointing.

### 4. `CacheManager` (Hash-Based Caching)

-   **Purpose**: Caches LLM responses and tool execution results to reduce latency and API costs.
-   **Inspiration**: Deep SSnaHke's `CACHE.tsv` and `cache_lookup`/`cache_set` functions.
-   **Implementation**: File-based JSON store (e.g., `cache.json`).
-   **Features**: Hash-based keys (e.g., `sha256(input)`), configurable TTL, automatic expiration of stale entries.

### 5. `LLMProvider` (LLM Abstraction Layer)

-   **Purpose**: Provides a unified interface for interacting with various LLM APIs.
-   **User Requirement**: Support for OpenAI, Copilot free mode, local LLMs (Ollama, LM Studio), and user-provided APIs.
-   **Implementation**: An abstract base class with concrete implementations for each provider. Each implementation handles authentication, request/response formatting, and streaming.
-   **Features**: Dynamic provider selection based on configuration, token management, streaming support, tool call parsing.

### 6. `ToolRegistry` and `ToolExecutor` (Agentic Abilities & Tool Execution)

-   **Purpose**: Manages and executes the tools available to the agent.
-   **Inspiration**: FSAgent's methods (`get_all_files`, `delete_duplicates`), ADK 2.0's 
Custom Tools, and the `ToolDispatcher` from the `agentic-worker` skill.
-   **`ToolRegistry`**: A central place to register all available tools. Tools can be:
    -   **Built-in**: File system operations (read, write, delete, list), shell command execution, Git operations (clone, commit, push, branch, PR creation).
    -   **External API Wrappers**: Generic wrappers for calling any API (e.g., via OpenAPI spec or simple HTTP requests).
    -   **User-defined**: Custom Python functions provided by the user.
-   **`ToolExecutor`**: Dispatches tool calls, potentially in parallel.
    -   **Parallel Execution**: Uses `concurrent.futures.ThreadPoolExecutor` (like `xargs -P` in Deep SSnaHke) for concurrent tool execution.
    -   **Caching**: Integrates with `CacheManager` to cache tool results.
    -   **Dry-Run**: Supports a global dry-run mode and per-tool dry-run flags.
    -   **Confirmation**: For destructive actions, can prompt for user confirmation (CLI interactive mode).
    -   **Error Handling**: Robust error capture and reporting.

### 7. `AgentLoop` (Orchestration & Control Flow)

-   **Purpose**: The central control unit that orchestrates the multi-turn LLM interactions, tool execution, and state management.
-   **Inspiration**: Deep SSnaHke's `main()` loop (`while true; do ... sleep $INTERVAL; done`), ADK 2.0's Graph Workflows and Event Loop.
-   **Modes of Operation**:
    -   **One-Shot**: Executes a single turn and exits.
    -   **Daemon**: Runs continuously in the background with a configurable interval, checking for new tasks or continuing existing ones.
    -   **Interactive (REPL)**: Provides a command-line interface for direct user interaction and task guidance.
    -   **GitHub/GitLab Actions Worker**: Can be invoked by CI/CD pipelines to perform tasks.
-   **Key Steps per Turn**:
    1.  Load state (`StateManager`).
    2.  Formulate prompt (based on goal, history, available tools).
    3.  Call LLM (`LLMProvider`).
    4.  Parse LLM response (text, tool calls, new plan).
    5.  Execute tools (`ToolExecutor`) if requested by LLM.
    6.  Update state (`StateManager`).
    7.  Log events (`Logger`).

### 8. `Deployment` (CLI & CI/CD Integration)

-   **Purpose**: Defines how the agent is packaged and run.
-   **User Requirement**: Local terminal execution and GitHub/GitLab Actions worker.
-   **CLI Interface**: Uses `argparse` (or similar) for command-line arguments to control agent behavior (e.g., `--once`, `--daemon`, `--interactive`, `--config-file`).
-   **GitHub/GitLab Actions**: The CLI tool can be wrapped in a Docker container or directly executed within a CI/CD job. Environment variables will be used to pass configurations and API keys. The agent can then perform Git operations (e.g., create branches, commit changes, open PRs) as part of its toolset.

## LLM Provider Integration Strategy

To support 
multiple LLM providers, a flexible strategy is required:

-   **Pydantic Models for Configuration**: Define Pydantic models for each LLM provider (e.g., `OpenAIConfig`, `CopilotConfig`, `OllamaConfig`) to validate and structure API keys, endpoints, and model names.
-   **Factory Pattern for `LLMProvider`**: A factory function will instantiate the correct `LLMProvider` subclass based on the `AGENT_LLM_PROVIDER` environment variable or CLI argument.
-   **Dynamic Tool Schema Generation**: Each `LLMProvider` will be responsible for converting the `ToolRegistry`'s registered tools into the specific tool schema format required by the underlying LLM (e.g., OpenAI function calling format, Gemini tool definitions).
-   **Copilot Free Mode**: This will likely involve a specialized `CopilotProvider` that interacts with the Copilot API, potentially requiring specific authentication flows or session management.
-   **Local LLMs (Ollama, LM Studio)**: The `OllamaProvider` or `LMStudioProvider` will connect to local endpoints, allowing users to leverage their own hardware.

## Tool Execution Capabilities

To achieve "everything possible" agentic abilities, the `ToolRegistry` will include a comprehensive set of tools:

### 1. File System Tools

-   `read_file(path: str)`: Reads content of a file.
-   `write_file(path: str, content: str)`: Writes content to a file (overwrites if exists).
-   `append_to_file(path: str, content: str)`: Appends content to a file.
-   `delete_file(path: str)`: Deletes a file.
-   `list_directory(path: str)`: Lists contents of a directory.
-   `create_directory(path: str)`: Creates a new directory.
-   `move_file(source: str, destination: str)`: Moves a file or directory.
-   `copy_file(source: str, destination: str)`: Copies a file.

### 2. Shell Command Execution Tool

-   `execute_shell_command(command: str, timeout: int = 60)`: Executes an arbitrary shell command.
-   **Safety**: Will include warnings and require explicit `DRY_RUN=False` for execution, especially for commands that could be destructive.

### 3. Git Operations Tools

-   `git_clone(repo_url: str, target_dir: str)`: Clones a Git repository.
-   `git_checkout(branch_name: str)`: Checks out a Git branch.
-   `git_add(files: List[str])`: Stages files for commit.
-   `git_commit(message: str)`: Commits staged changes.
-   `git_push(remote: str = "origin", branch: str = "main")`: Pushes changes to a remote repository.
-   `git_create_branch(branch_name: str)`: Creates a new branch.
-   `git_create_pull_request(title: str, body: str, base_branch: str = "main", head_branch: str)`: Creates a pull request (requires GitHub/GitLab API integration).

### 4. External API Calling Tool

-   `call_api(method: str, url: str, headers: Dict[str, str] = None, body: Dict[str, Any] = None)`: A generic tool to make HTTP requests to any external API.
-   **Features**: Supports GET, POST, PUT, DELETE. Handles JSON request bodies and responses. Can be extended with authentication mechanisms (e.g., API keys, OAuth tokens).

### 5. User-Provided Custom Tools

-   The `ToolRegistry` will allow users to dynamically register their own Python functions as tools, similar to how the `agentic-worker` skill currently operates.

## GitHub/GitLab Actions Integration

-   **Docker Container**: The agent will be packaged into a Docker image. This image can be used as a custom action in GitHub Actions or a custom job in GitLab CI/CD.
-   **Input/Output**: Agent goals, configurations, and API keys will be passed as environment variables or action inputs.
-   **Git Context**: The agent will operate within the Git repository context of the CI/CD pipeline, allowing it to perform Git operations directly on the codebase.
-   **Output Artifacts**: Agent logs, generated files, or reports can be uploaded as CI/CD artifacts.

## Overall Workflow

```mermaid
graph TD
    A[User/Scheduler] --> B(CLI/GitHub Action Trigger)
    B --> C{AgentConfig}
    C --> D[AgentLoop]
    D --> E[StateManager]
    D --> F[CacheManager]
    D --> G[LLMProvider]
    D --> H[ToolExecutor]
    H --> I[ToolRegistry]
    I --> J[File System Tools]
    I --> K[Shell Tools]
    I --> L[Git Tools]
    I --> M[External API Tool]
    I --> N[User-Defined Tools]
    G --> O[OpenAI/Copilot/Local LLMs]
    H --> P[External Systems/APIs]
    D --> Q[Logger]

    subgraph Persistence
        E -- Reads/Writes --> R[state.json]
        F -- Reads/Writes --> S[cache.json]
    end

    Q -- Writes to --> T[trail.log]

    style A fill:#f9f,stroke:#333,stroke-width:2px
    style B fill:#bbf,stroke:#333,stroke-width:2px
    style C fill:#ccf,stroke:#333,stroke-width:2px
    style D fill:#cfc,stroke:#333,stroke-width:2px
    style E fill:#fcc,stroke:#333,stroke-width:2px
    style F fill:#fcf,stroke:#333,stroke-width:2px
    style G fill:#ffc,stroke:#333,stroke-width:2px
    style H fill:#cff,stroke:#333,stroke-width:2px
    style I fill:#eee,stroke:#333,stroke-width:1px
    style J fill:#eee,stroke:#333,stroke-width:1px
    style K fill:#eee,stroke:#333,stroke-width:1px
    style L fill:#eee,stroke:#333,stroke-width:1px
    style M fill:#eee,stroke:#333,stroke-width:1px
    style N fill:#eee,stroke:#333,stroke-width:1px
    style O fill:#ddd,stroke:#333,stroke-width:1px
    style P fill:#ddd,stroke:#333,stroke-width:1px
    style Q fill:#eee,stroke:#333,stroke-width:1px
    style R fill:#eee,stroke:#333,stroke-width:1px
    style S fill:#eee,stroke:#333,stroke-width:1px
    style T fill:#eee,stroke:#333,stroke-width:1px
```

This architecture provides a comprehensive and flexible foundation for a truly agentic AI worker, capable of adapting to diverse tasks and environments while maintaining robustness and observability.
