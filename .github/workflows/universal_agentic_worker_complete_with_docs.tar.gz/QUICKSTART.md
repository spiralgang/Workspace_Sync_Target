# Universal Agentic Worker - Quick Start Guide

## 🚀 Get Started in 5 Minutes

### Option 1: CLI (Fastest)

```bash
cd /home/ubuntu/universal_agentic_worker
./launcher.sh --mode interactive
```

Done! You now have an interactive AI agent in your terminal.

---

### Option 2: Web Dashboard (Browser)

```bash
cd /home/ubuntu/universal_agentic_worker_rci
pip3 install -r requirements.txt
python3 app/main.py
```

Open `http://localhost:8000` in your browser.

---

### Option 3: Progressive Web App (PWA)

```bash
cd /home/ubuntu/universal_agentic_worker_pwa
npm install
npm run dev
```

Open `http://localhost:3000` in your browser. Can be installed as an app!

---

### Option 4: Android APK

```bash
cd /home/ubuntu/universal_agentic_worker_apk
./build.sh
```

Transfer the APK to your Android device and install.

---

## 🔧 Configuration

### Set Your LLM Provider

#### OpenAI (GPT-4o)

```bash
export OPENAI_API_KEY="sk-your-key-here"
./launcher.sh --llm-provider openai --llm-model gpt-4o
```

#### Google Gemini

```bash
export GEMINI_API_KEY="your-key-here"
./launcher.sh --llm-provider gemini --llm-model gemini-pro
```

#### Local Ollama (Free!)

```bash
# First, install Ollama from ollama.ai
ollama pull llama2
ollama serve

# In another terminal:
./launcher.sh --llm-provider ollama --llm-model llama2
```

---

## 📋 Common Tasks

### Create a File

```
You: Create a file called hello.txt with content "Hello, World!"
Agent: I'll create that file for you.
[File created successfully]
```

### Execute Shell Commands

```
You: List all Python files in the current directory
Agent: I'll list all .py files for you.
[Output of ls *.py]
```

### Git Operations

```
You: Clone the repository https://github.com/user/repo.git
Agent: I'll clone that repository.
[Repository cloned]
```

### LLM Analysis

```
You: Analyze this code and suggest improvements
Agent: [Provides detailed analysis and suggestions]
```

---

## 🎯 Example Workflows

### Workflow 1: File Organization

```bash
./launcher.sh --mode one-shot --prompt "Organize all files in ~/Downloads by type (documents, images, videos, etc.)"
```

### Workflow 2: Code Analysis

```bash
./launcher.sh --mode interactive --prompt "You are a code reviewer. Analyze code files and provide feedback."
```

### Workflow 3: Automated Backup

```bash
./launcher.sh --mode daemon --prompt "Monitor ~/important and backup new files to ~/backups every 5 minutes"
```

---

## 🛡️ Safety First

### Always Start with Dry-Run

```bash
./launcher.sh --dry-run  # No files will be deleted/modified
```

### Test Before Production

1. Run with `--dry-run` first
2. Review the planned actions
3. Remove `--dry-run` to execute

---

## 📱 Platform-Specific Tips

### Linux/macOS Terminal

```bash
# Make launcher executable
chmod +x launcher.sh

# Run with custom prompt
./launcher.sh --prompt "Your task here"
```

### Windows PowerShell

```powershell
# Install Python 3.8+
python main.py --mode interactive

# Or use WSL for bash script
wsl ./launcher.sh
```

### Android

1. Install the APK
2. Grant file/network permissions
3. Configure API keys in Settings
4. Start an agent

### Browser (PWA)

1. Open in Chrome/Edge
2. Click "Install app"
3. Works offline!
4. Access from home screen

---

## 🔌 API Integration

### From Python

```python
import subprocess
import json

result = subprocess.run([
    'python3', 'main.py',
    '--agent-id', 'my_agent',
    '--mode', 'one-shot',
    '--prompt', 'List all files'
], capture_output=True, text=True)

print(result.stdout)
```

### From JavaScript (Web RCI)

```javascript
const response = await fetch('/api/agent/start', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
        agentId: 'web_agent',
        mode: 'interactive',
        prompt: 'Help me with file management'
    })
});
```

---

## 🐛 Troubleshooting

### Agent won't start

```bash
# Check Python version
python3 --version  # Should be 3.8+

# Install dependencies
pip3 install -r requirements.txt

# Check logs
tail -f ~/.universal_agent/trail.log
```

### LLM connection error

```bash
# Test API key
curl https://api.openai.com/v1/models -H "Authorization: Bearer $OPENAI_API_KEY"

# Or for Ollama
curl http://localhost:11434/api/tags
```

### Port already in use

```bash
# Find what's using port 8000
lsof -i :8000

# Kill it
kill -9 <PID>

# Or use different port
python3 app/main.py --port 9000
```

---

## 📚 Learn More

- **Full Docs**: `DEPLOYMENT_GUIDE.md`
- **Architecture**: `universal_agentic_worker_architecture.md`
- **README**: `universal_agentic_worker/README.md`

---

## 🎓 Next Steps

1. **Try the CLI first** - Easiest way to get started
2. **Explore the Web Dashboard** - Visual interface
3. **Install as PWA** - Use like a native app
4. **Deploy to Android** - Take it with you
5. **Integrate with your tools** - Use the APIs

---

**Happy agenting! 🤖**
