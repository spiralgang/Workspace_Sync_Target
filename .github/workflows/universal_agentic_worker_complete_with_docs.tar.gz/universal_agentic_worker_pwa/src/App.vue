<template>
  <div class="app-container">
    <header class="app-header">
      <h1>⚙️ Universal Agentic Worker</h1>
      <div class="header-controls">
        <button @click="toggleTheme" class="theme-toggle">🌙</button>
        <button @click="showSettings = !showSettings" class="settings-btn">⚙️</button>
      </div>
    </header>

    <main class="app-main">
      <div class="layout">
        <!-- Configuration Panel -->
        <section class="config-panel">
          <h2>Agent Configuration</h2>
          
          <div class="form-group">
            <label>Agent ID</label>
            <input v-model="config.agentId" type="text" placeholder="e.g., my_agent_001">
          </div>

          <div class="form-group">
            <label>Mode</label>
            <select v-model="config.mode">
              <option>one-shot</option>
              <option>daemon</option>
              <option>interactive</option>
            </select>
          </div>

          <div class="form-group">
            <label>System Prompt</label>
            <textarea v-model="config.prompt" placeholder="Enter system prompt" rows="4"></textarea>
          </div>

          <div class="form-group">
            <label>LLM Provider</label>
            <select v-model="config.llmProvider">
              <option>openai</option>
              <option>gemini</option>
              <option>copilot</option>
              <option>ollama</option>
            </select>
          </div>

          <div class="form-group">
            <label>LLM Model</label>
            <input v-model="config.llmModel" type="text" placeholder="e.g., gpt-4o">
          </div>

          <div class="form-group checkbox">
            <input v-model="config.dryRun" type="checkbox" id="dry-run">
            <label for="dry-run">Dry Run Mode (no destructive actions)</label>
          </div>

          <div class="button-group">
            <button @click="startAgent" class="btn btn-primary">▶️ Start Agent</button>
            <button @click="stopAgent" class="btn btn-danger">⏹️ Stop Agent</button>
          </div>
        </section>

        <!-- Terminal Panel -->
        <section class="terminal-panel">
          <h2>Terminal Output</h2>
          <div class="terminal" ref="terminal"></div>
          <div class="terminal-input">
            <input v-model="terminalInput" @keyup.enter="sendCommand" type="text" placeholder="Enter command...">
            <button @click="sendCommand" class="btn btn-small">Send</button>
          </div>
        </section>
      </div>

      <!-- Status Bar -->
      <div class="status-bar">
        <span class="status-indicator" :class="agentStatus"></span>
        <span class="status-text">{{ statusMessage }}</span>
        <span class="status-time">{{ currentTime }}</span>
      </div>
    </main>

    <!-- Settings Modal -->
    <div v-if="showSettings" class="modal-overlay" @click="showSettings = false">
      <div class="modal" @click.stop>
        <h2>Settings</h2>
        <div class="settings-content">
          <div class="setting-group">
            <label>API Keys</label>
            <input v-model="apiKeys.openai" type="password" placeholder="OpenAI API Key">
            <input v-model="apiKeys.gemini" type="password" placeholder="Gemini API Key">
            <input v-model="apiKeys.ollama" type="text" placeholder="Ollama Base URL">
          </div>
          <div class="button-group">
            <button @click="saveSettings" class="btn btn-primary">Save</button>
            <button @click="showSettings = false" class="btn">Cancel</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, onMounted, onUnmounted } from 'vue';
import axios from 'axios';

export default {
  name: 'App',
  setup() {
    const config = ref({
      agentId: 'pwa_agent_001',
      mode: 'interactive',
      prompt: 'You are a helpful AI assistant with access to file system, shell commands, and Git operations.',
      llmProvider: 'openai',
      llmModel: 'gpt-4o',
      dryRun: true
    });

    const apiKeys = ref({
      openai: localStorage.getItem('openai_key') || '',
      gemini: localStorage.getItem('gemini_key') || '',
      ollama: localStorage.getItem('ollama_url') || 'http://localhost:11434'
    });

    const agentStatus = ref('idle');
    const statusMessage = ref('Ready');
    const currentTime = ref('');
    const showSettings = ref(false);
    const terminalInput = ref('');
    const terminal = ref(null);
    const terminalContent = ref([]);

    // Update time
    const updateTime = () => {
      const now = new Date();
      currentTime.value = now.toLocaleTimeString();
    };

    onMounted(() => {
      updateTime();
      setInterval(updateTime, 1000);
      registerServiceWorker();
    });

    const registerServiceWorker = async () => {
      if ('serviceWorker' in navigator) {
        try {
          await navigator.serviceWorker.register('/sw.js');
          console.log('Service Worker registered');
        } catch (error) {
          console.error('Service Worker registration failed:', error);
        }
      }
    };

    const startAgent = async () => {
      agentStatus.value = 'running';
      statusMessage.value = `Starting agent: ${config.value.agentId}`;
      
      try {
        const response = await axios.post('/api/agent/start', config.value);
        addTerminalOutput(`Agent started: ${response.data.message}`);
      } catch (error) {
        agentStatus.value = 'error';
        statusMessage.value = 'Error starting agent';
        addTerminalOutput(`Error: ${error.message}`);
      }
    };

    const stopAgent = async () => {
      try {
        await axios.post('/api/agent/stop');
        agentStatus.value = 'idle';
        statusMessage.value = 'Agent stopped';
        addTerminalOutput('Agent stopped');
      } catch (error) {
        addTerminalOutput(`Error stopping agent: ${error.message}`);
      }
    };

    const sendCommand = async () => {
      if (!terminalInput.value.trim()) return;

      addTerminalOutput(`$ ${terminalInput.value}`);
      
      try {
        const response = await axios.post('/api/terminal/execute', {
          command: terminalInput.value
        });
        addTerminalOutput(response.data.output);
      } catch (error) {
        addTerminalOutput(`Error: ${error.message}`);
      }
      
      terminalInput.value = '';
    };

    const addTerminalOutput = (text) => {
      terminalContent.value.push(text);
      if (terminal.value) {
        terminal.value.innerHTML += `<div>${text}</div>`;
        terminal.value.scrollTop = terminal.value.scrollHeight;
      }
    };

    const saveSettings = () => {
      localStorage.setItem('openai_key', apiKeys.value.openai);
      localStorage.setItem('gemini_key', apiKeys.value.gemini);
      localStorage.setItem('ollama_url', apiKeys.value.ollama);
      statusMessage.value = 'Settings saved';
      showSettings.value = false;
    };

    const toggleTheme = () => {
      document.body.classList.toggle('dark-theme');
    };

    return {
      config,
      apiKeys,
      agentStatus,
      statusMessage,
      currentTime,
      showSettings,
      terminalInput,
      terminal,
      startAgent,
      stopAgent,
      sendCommand,
      saveSettings,
      toggleTheme
    };
  }
};
</script>

<style scoped>
.app-container {
  display: flex;
  flex-direction: column;
  height: 100vh;
  background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%);
  color: #e0e0e0;
}

.app-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px;
  background: rgba(0, 0, 0, 0.3);
  border-bottom: 2px solid #00ff88;
  box-shadow: 0 2px 10px rgba(0, 255, 136, 0.1);
}

.app-header h1 {
  font-size: 24px;
  font-weight: bold;
  color: #00ff88;
  text-shadow: 0 0 10px rgba(0, 255, 136, 0.5);
}

.header-controls {
  display: flex;
  gap: 10px;
}

.theme-toggle, .settings-btn {
  background: rgba(0, 255, 136, 0.1);
  border: 1px solid #00ff88;
  color: #00ff88;
  padding: 8px 12px;
  cursor: pointer;
  border-radius: 4px;
  transition: all 0.3s;
}

.theme-toggle:hover, .settings-btn:hover {
  background: rgba(0, 255, 136, 0.2);
  box-shadow: 0 0 10px rgba(0, 255, 136, 0.3);
}

.app-main {
  flex: 1;
  overflow: auto;
  padding: 20px;
}

.layout {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
  height: 100%;
}

@media (max-width: 1024px) {
  .layout {
    grid-template-columns: 1fr;
  }
}

.config-panel, .terminal-panel {
  background: rgba(0, 0, 0, 0.2);
  border: 1px solid #00ff88;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 0 20px rgba(0, 255, 136, 0.1);
}

.config-panel h2, .terminal-panel h2 {
  color: #00ff88;
  margin-bottom: 15px;
  font-size: 18px;
}

.form-group {
  margin-bottom: 15px;
}

.form-group label {
  display: block;
  margin-bottom: 5px;
  color: #00ff88;
  font-size: 14px;
  font-weight: 500;
}

.form-group input,
.form-group select,
.form-group textarea {
  width: 100%;
  padding: 10px;
  background: rgba(0, 0, 0, 0.3);
  border: 1px solid #00ff88;
  color: #e0e0e0;
  border-radius: 4px;
  font-family: 'Courier New', monospace;
  font-size: 14px;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
  outline: none;
  box-shadow: 0 0 10px rgba(0, 255, 136, 0.3);
  border-color: #00ffff;
}

.form-group.checkbox {
  display: flex;
  align-items: center;
  gap: 10px;
}

.form-group.checkbox input {
  width: auto;
}

.button-group {
  display: flex;
  gap: 10px;
  margin-top: 20px;
}

.btn {
  flex: 1;
  padding: 10px 20px;
  border: 1px solid #00ff88;
  background: rgba(0, 255, 136, 0.1);
  color: #00ff88;
  cursor: pointer;
  border-radius: 4px;
  font-weight: 500;
  transition: all 0.3s;
}

.btn:hover {
  background: rgba(0, 255, 136, 0.2);
  box-shadow: 0 0 10px rgba(0, 255, 136, 0.3);
}

.btn-primary {
  background: rgba(0, 255, 136, 0.2);
  border-color: #00ff88;
}

.btn-primary:hover {
  background: rgba(0, 255, 136, 0.3);
}

.btn-danger {
  border-color: #ff0055;
  color: #ff0055;
  background: rgba(255, 0, 85, 0.1);
}

.btn-danger:hover {
  background: rgba(255, 0, 85, 0.2);
  box-shadow: 0 0 10px rgba(255, 0, 85, 0.3);
}

.btn-small {
  flex: 0 0 auto;
  padding: 8px 15px;
  font-size: 12px;
}

.terminal {
  background: rgba(0, 0, 0, 0.5);
  border: 1px solid #00ff88;
  border-radius: 4px;
  padding: 15px;
  height: 300px;
  overflow-y: auto;
  font-family: 'Courier New', monospace;
  font-size: 12px;
  color: #00ff88;
  margin-bottom: 10px;
  line-height: 1.5;
}

.terminal div {
  margin-bottom: 5px;
  word-break: break-all;
}

.terminal-input {
  display: flex;
  gap: 10px;
}

.terminal-input input {
  flex: 1;
  padding: 10px;
  background: rgba(0, 0, 0, 0.3);
  border: 1px solid #00ff88;
  color: #00ff88;
  border-radius: 4px;
  font-family: 'Courier New', monospace;
  font-size: 14px;
}

.terminal-input input:focus {
  outline: none;
  box-shadow: 0 0 10px rgba(0, 255, 136, 0.3);
}

.status-bar {
  display: flex;
  align-items: center;
  gap: 15px;
  padding: 15px 20px;
  background: rgba(0, 0, 0, 0.3);
  border-top: 1px solid #00ff88;
  margin-top: 20px;
  border-radius: 4px;
}

.status-indicator {
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background: #ff0055;
  animation: pulse 2s infinite;
}

.status-indicator.running {
  background: #00ff88;
}

.status-indicator.idle {
  background: #ffaa00;
  animation: none;
}

.status-indicator.error {
  background: #ff0055;
  animation: pulse-error 0.5s infinite;
}

@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
}

@keyframes pulse-error {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.3; }
}

.status-text {
  flex: 1;
  color: #e0e0e0;
}

.status-time {
  color: #00ff88;
  font-family: 'Courier New', monospace;
  font-size: 12px;
}

.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.7);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal {
  background: #1a1a1a;
  border: 2px solid #00ff88;
  border-radius: 8px;
  padding: 30px;
  max-width: 400px;
  width: 90%;
  box-shadow: 0 0 30px rgba(0, 255, 136, 0.2);
}

.modal h2 {
  color: #00ff88;
  margin-bottom: 20px;
}

.settings-content {
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.setting-group input {
  width: 100%;
  padding: 10px;
  background: rgba(0, 0, 0, 0.3);
  border: 1px solid #00ff88;
  color: #e0e0e0;
  border-radius: 4px;
  margin-bottom: 10px;
  font-family: 'Courier New', monospace;
}
</style>
