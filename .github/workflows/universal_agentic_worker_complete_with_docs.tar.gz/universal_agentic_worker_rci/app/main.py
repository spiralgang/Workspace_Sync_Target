#!/usr/bin/env python3
"""
Universal Agentic Worker - Web RCI Backend
FastAPI server for remote command interface and agent control
"""

from fastapi import FastAPI, WebSocket, HTTPException, BackgroundTasks
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
import asyncio
import json
import subprocess
import os
import sys
from pathlib import Path
from typing import Dict, List
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Universal Agentic Worker RCI")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Store for active agent processes
active_agents: Dict[str, subprocess.Popen] = {}
agent_logs: Dict[str, List[str]] = {}

# Mount static files
static_path = Path(__file__).parent.parent / "static"
if static_path.exists():
    app.mount("/static", StaticFiles(directory=str(static_path)), name="static")


@app.get("/", response_class=HTMLResponse)
async def root():
    """Serve main dashboard HTML"""
    return """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Universal Agentic Worker - RCI</title>
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            body {
                font-family: 'Courier New', monospace;
                background: linear-gradient(135deg, #0a0e27 0%, #1a1f3a 100%);
                color: #00ff88;
                min-height: 100vh;
                padding: 20px;
            }
            .container {
                max-width: 1400px;
                margin: 0 auto;
            }
            header {
                text-align: center;
                margin-bottom: 30px;
                padding: 20px;
                border: 2px solid #00ff88;
                border-radius: 8px;
                background: rgba(0, 255, 136, 0.05);
                box-shadow: 0 0 20px rgba(0, 255, 136, 0.1);
            }
            header h1 {
                font-size: 32px;
                text-shadow: 0 0 10px rgba(0, 255, 136, 0.5);
                margin-bottom: 10px;
            }
            .layout {
                display: grid;
                grid-template-columns: 1fr 2fr;
                gap: 20px;
            }
            @media (max-width: 1024px) {
                .layout {
                    grid-template-columns: 1fr;
                }
            }
            .panel {
                border: 2px solid #00ff88;
                border-radius: 8px;
                padding: 20px;
                background: rgba(0, 0, 0, 0.3);
                box-shadow: 0 0 20px rgba(0, 255, 136, 0.1);
            }
            .panel h2 {
                margin-bottom: 15px;
                color: #00ffff;
                border-bottom: 1px solid #00ff88;
                padding-bottom: 10px;
            }
            .form-group {
                margin-bottom: 15px;
            }
            .form-group label {
                display: block;
                margin-bottom: 5px;
                color: #00ff88;
                font-weight: bold;
            }
            .form-group input,
            .form-group select,
            .form-group textarea {
                width: 100%;
                padding: 10px;
                background: rgba(0, 0, 0, 0.5);
                border: 1px solid #00ff88;
                color: #00ff88;
                border-radius: 4px;
                font-family: 'Courier New', monospace;
                font-size: 13px;
            }
            .form-group input:focus,
            .form-group select:focus,
            .form-group textarea:focus {
                outline: none;
                box-shadow: 0 0 10px rgba(0, 255, 136, 0.3);
                border-color: #00ffff;
            }
            .button-group {
                display: flex;
                gap: 10px;
                margin-top: 20px;
            }
            button {
                flex: 1;
                padding: 10px 20px;
                background: rgba(0, 255, 136, 0.1);
                border: 1px solid #00ff88;
                color: #00ff88;
                cursor: pointer;
                border-radius: 4px;
                font-family: 'Courier New', monospace;
                font-weight: bold;
                transition: all 0.3s;
            }
            button:hover {
                background: rgba(0, 255, 136, 0.2);
                box-shadow: 0 0 10px rgba(0, 255, 136, 0.3);
            }
            button.danger {
                border-color: #ff0055;
                color: #ff0055;
                background: rgba(255, 0, 85, 0.1);
            }
            button.danger:hover {
                background: rgba(255, 0, 85, 0.2);
                box-shadow: 0 0 10px rgba(255, 0, 85, 0.3);
            }
            .terminal {
                background: rgba(0, 0, 0, 0.7);
                border: 1px solid #00ff88;
                border-radius: 4px;
                padding: 15px;
                height: 400px;
                overflow-y: auto;
                font-size: 12px;
                line-height: 1.5;
                margin-bottom: 15px;
                font-family: 'Courier New', monospace;
            }
            .terminal-line {
                margin-bottom: 5px;
                word-break: break-all;
            }
            .terminal-input {
                display: flex;
                gap: 10px;
            }
            .terminal-input input {
                flex: 1;
                padding: 10px;
                background: rgba(0, 0, 0, 0.5);
                border: 1px solid #00ff88;
                color: #00ff88;
                border-radius: 4px;
                font-family: 'Courier New', monospace;
            }
            .terminal-input button {
                flex: 0 0 auto;
                padding: 10px 20px;
            }
            .status {
                display: flex;
                align-items: center;
                gap: 10px;
                padding: 10px;
                background: rgba(0, 0, 0, 0.3);
                border: 1px solid #00ff88;
                border-radius: 4px;
                margin-top: 15px;
            }
            .status-indicator {
                width: 12px;
                height: 12px;
                border-radius: 50%;
                background: #ff0055;
                animation: pulse 2s infinite;
            }
            .status-indicator.active {
                background: #00ff88;
            }
            @keyframes pulse {
                0%, 100% { opacity: 1; }
                50% { opacity: 0.5; }
            }
            .checkbox-group {
                display: flex;
                align-items: center;
                gap: 10px;
            }
            .checkbox-group input {
                width: auto;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <header>
                <h1>⚙️ Universal Agentic Worker - RCI</h1>
                <p>Remote Command Interface & Agent Control</p>
            </header>

            <div class="layout">
                <!-- Control Panel -->
                <div class="panel">
                    <h2>Agent Control</h2>
                    
                    <div class="form-group">
                        <label>Agent ID</label>
                        <input id="agentId" type="text" value="web_rci_agent" placeholder="Agent ID">
                    </div>

                    <div class="form-group">
                        <label>Mode</label>
                        <select id="mode">
                            <option>one-shot</option>
                            <option selected>interactive</option>
                            <option>daemon</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>LLM Provider</label>
                        <select id="llmProvider">
                            <option selected>openai</option>
                            <option>gemini</option>
                            <option>copilot</option>
                            <option>ollama</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>LLM Model</label>
                        <input id="llmModel" type="text" value="gpt-4o" placeholder="Model name">
                    </div>

                    <div class="form-group">
                        <label>System Prompt</label>
                        <textarea id="prompt" rows="4" placeholder="Enter system prompt">You are a helpful AI assistant with full access to file system, shell commands, and Git operations.</textarea>
                    </div>

                    <div class="form-group checkbox-group">
                        <input id="dryRun" type="checkbox" checked>
                        <label for="dryRun">Dry Run Mode</label>
                    </div>

                    <div class="button-group">
                        <button onclick="startAgent()">▶️ Start</button>
                        <button onclick="stopAgent()" class="danger">⏹️ Stop</button>
                    </div>

                    <div class="status">
                        <div class="status-indicator" id="statusIndicator"></div>
                        <span id="statusText">Ready</span>
                    </div>
                </div>

                <!-- Terminal Panel -->
                <div class="panel">
                    <h2>Terminal & Output</h2>
                    <div class="terminal" id="terminal"></div>
                    <div class="terminal-input">
                        <input id="commandInput" type="text" placeholder="Enter command..." onkeyup="if(event.key==='Enter') executeCommand()">
                        <button onclick="executeCommand()">Execute</button>
                    </div>
                </div>
            </div>
        </div>

        <script>
            const terminal = document.getElementById('terminal');
            const statusIndicator = document.getElementById('statusIndicator');
            const statusText = document.getElementById('statusText');

            function addLog(text) {
                const line = document.createElement('div');
                line.className = 'terminal-line';
                line.textContent = text;
                terminal.appendChild(line);
                terminal.scrollTop = terminal.scrollHeight;
            }

            async function startAgent() {
                const config = {
                    agentId: document.getElementById('agentId').value,
                    mode: document.getElementById('mode').value,
                    prompt: document.getElementById('prompt').value,
                    llmProvider: document.getElementById('llmProvider').value,
                    llmModel: document.getElementById('llmModel').value,
                    dryRun: document.getElementById('dryRun').checked
                };

                try {
                    const response = await fetch('/api/agent/start', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(config)
                    });
                    const data = await response.json();
                    addLog(`✓ Agent started: ${data.message}`);
                    statusIndicator.classList.add('active');
                    statusText.textContent = 'Agent Running';
                } catch (error) {
                    addLog(`✗ Error: ${error.message}`);
                    statusText.textContent = 'Error';
                }
            }

            async function stopAgent() {
                try {
                    const response = await fetch('/api/agent/stop', { method: 'POST' });
                    const data = await response.json();
                    addLog(`✓ Agent stopped`);
                    statusIndicator.classList.remove('active');
                    statusText.textContent = 'Stopped';
                } catch (error) {
                    addLog(`✗ Error: ${error.message}`);
                }
            }

            async function executeCommand() {
                const command = document.getElementById('commandInput').value;
                if (!command.trim()) return;

                addLog(`$ ${command}`);
                document.getElementById('commandInput').value = '';

                try {
                    const response = await fetch('/api/terminal/execute', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ command })
                    });
                    const data = await response.json();
                    if (data.output) {
                        data.output.split('\\n').forEach(line => addLog(line));
                    }
                } catch (error) {
                    addLog(`✗ Error: ${error.message}`);
                }
            }

            // Initialize
            addLog('Universal Agentic Worker RCI - Ready');
            addLog('Type commands below or use the control panel to start an agent');
        </script>
    </body>
    </html>
    """


@app.post("/api/agent/start")
async def start_agent(config: dict, background_tasks: BackgroundTasks):
    """Start a new agent instance"""
    agent_id = config.get("agentId", "default_agent")
    
    if agent_id in active_agents:
        raise HTTPException(status_code=400, detail="Agent already running")
    
    agent_logs[agent_id] = []
    
    # Build command
    cmd = [
        sys.executable,
        "/home/ubuntu/universal_agentic_worker/main.py",
        "--agent-id", agent_id,
        "--mode", config.get("mode", "interactive"),
        "--prompt", config.get("prompt", ""),
        "--llm-provider", config.get("llmProvider", "openai"),
        "--llm-model", config.get("llmModel", "gpt-4o")
    ]
    
    if config.get("dryRun", True):
        cmd.append("--dry-run")
    
    try:
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1
        )
        active_agents[agent_id] = process
        logger.info(f"Started agent: {agent_id}")
        return {"message": f"Agent {agent_id} started successfully"}
    except Exception as e:
        logger.error(f"Failed to start agent: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/agent/stop")
async def stop_agent(agent_id: str = "default_agent"):
    """Stop a running agent"""
    if agent_id not in active_agents:
        raise HTTPException(status_code=404, detail="Agent not found")
    
    process = active_agents[agent_id]
    process.terminate()
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
    
    del active_agents[agent_id]
    logger.info(f"Stopped agent: {agent_id}")
    return {"message": f"Agent {agent_id} stopped"}


@app.post("/api/terminal/execute")
async def execute_command(data: dict):
    """Execute a shell command"""
    command = data.get("command", "")
    
    if not command:
        raise HTTPException(status_code=400, detail="Command cannot be empty")
    
    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=30
        )
        output = result.stdout + result.stderr
        return {"output": output, "returncode": result.returncode}
    except subprocess.TimeoutExpired:
        return {"output": "Command timed out", "returncode": -1}
    except Exception as e:
        logger.error(f"Command execution error: {e}")
        return {"output": f"Error: {str(e)}", "returncode": -1}


@app.get("/api/agent/status")
async def get_agent_status(agent_id: str = "default_agent"):
    """Get status of an agent"""
    if agent_id not in active_agents:
        return {"status": "stopped", "agent_id": agent_id}
    
    process = active_agents[agent_id]
    is_running = process.poll() is None
    
    return {
        "status": "running" if is_running else "stopped",
        "agent_id": agent_id,
        "pid": process.pid if is_running else None
    }


@app.get("/api/agents")
async def list_agents():
    """List all active agents"""
    agents = []
    for agent_id, process in active_agents.items():
        is_running = process.poll() is None
        agents.append({
            "id": agent_id,
            "status": "running" if is_running else "stopped",
            "pid": process.pid if is_running else None
        })
    return {"agents": agents}


@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown"""
    for agent_id, process in active_agents.items():
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
    logger.info("All agents terminated")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")
