
import os
import json
import hashlib
import time
from typing import Dict, Any, Optional

from agent_core.AgentConfig import config
from agent_core.Logger import logger

class CacheManager:
    """Manages hash-based caching for LLM responses and tool results, analogous to SSnaHke's cache.tsv."""

    def __init__(self, agent_id: str, ttl: int = config.CACHE_TTL):
        self.agent_id = agent_id
        self.cache_file = os.path.join(config.AGENT_STATE_DIR, f"{agent_id}_cache.json")
        self.ttl = ttl
        self.cache: Dict[str, Any] = self._load_cache()

    def _load_cache(self) -> Dict[str, Any]:
        if os.path.exists(self.cache_file):
            try:
                with open(self.cache_file, 'r') as f:
                    cache_data = json.load(f)
                    # Filter out expired entries
                    current_time = time.time()
                    active_cache = {
                        k: v for k, v in cache_data.items()
                        if current_time - v.get("timestamp", 0) < self.ttl
                    }
                    if len(cache_data) != len(active_cache):
                        logger.info("Cache pruned: expired entries removed.",
                                    event_data={
                                        "agent_id": self.agent_id,
                                        "expired_entries": len(cache_data) - len(active_cache)
                                    }))
                    logger.info("Cache loaded successfully.", event_data={"agent_id": self.agent_id, "cache_file": self.cache_file}))
                    return active_cache
            except json.JSONDecodeError as e:
                logger.error(f"Failed to decode cache file {self.cache_file}: {e}. Starting with empty cache.",
                             event_data={"agent_id": self.agent_id, "cache_file": self.cache_file, "error": str(e)}))
                return {}
            except Exception as e:
                logger.error(f"Error loading cache file {self.cache_file}: {e}. Starting with empty cache.",
                             event_data={"agent_id": self.agent_id, "cache_file": self.cache_file, "error": str(e)}))
                return {}
        logger.info("No existing cache file found. Starting with empty cache.", event_data={"agent_id": self.agent_id, "cache_file": self.cache_file}))
        return {}

    def _generate_key(self, data: Any) -> str:
        # Use a consistent, sorted JSON representation for hashing
        serialized_data = json.dumps(data, sort_keys=True).encode('utf-8')
        return hashlib.sha256(serialized_data).hexdigest()

    def get(self, data: Any) -> Optional[Any]:
        key = self._generate_key(data)
        entry = self.cache.get(key)
        if entry and (time.time() - entry.get("timestamp", 0) < self.ttl):
            logger.debug("Cache hit.", event_data={"agent_id": self.agent_id, "key": key}))
            return entry["value"]
        logger.debug("Cache miss.", event_data={"agent_id": self.agent_id, "key": key}))
        return None

    def set(self, data: Any, value: Any):
        key = self._generate_key(data)
        self.cache[key] = {"value": value, "timestamp": time.time()}
        self._save_cache()
        logger.debug("Cache set.", event_data={"agent_id": self.agent_id, "key": key}))

    def _save_cache(self):
        os.makedirs(os.path.dirname(self.cache_file), exist_ok=True)
        try:
            # Atomic write to prevent data corruption
            tmp_cache_file = self.cache_file + ".tmp"
            with open(tmp_cache_file, 'w') as f:
                json.dump(self.cache, f, indent=2)
            os.replace(tmp_cache_file, self.cache_file)
            logger.info("Cache saved successfully.", event_data={"agent_id": self.agent_id, "cache_file": self.cache_file}))
        except Exception as e:
            logger.error(f"Error saving cache file {self.cache_file}: {e}",
                         event_data={"agent_id": self.agent_id, "cache_file": self.cache_file, "error": str(e)}))

    def clear(self):
        self.cache = {}
        self._save_cache()
        logger.info("Cache cleared.", event_data={"agent_id": self.agent_id}))
