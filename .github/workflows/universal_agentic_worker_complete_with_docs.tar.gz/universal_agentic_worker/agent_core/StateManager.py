
import os
import json
from typing import Dict, Any, Optional

from agent_core.AgentConfig import config
from agent_core.Logger import logger

class StateManager:
    """Manages persistent state for the agent, analogous to SSnaHke's STATE_DIR and index files."""

    def __init__(self, agent_id: str):
        self.agent_id = agent_id
        self.state_file = os.path.join(config.AGENT_STATE_DIR, f"{agent_id}_state.json")
        self.state: Dict[str, Any] = self._load_state()

    def _load_state(self) -> Dict[str, Any]:
        if os.path.exists(self.state_file):
            try:
                with open(self.state_file, 'r') as f:
                    state_data = json.load(f)
                    logger.info("State loaded successfully.", event_data={"agent_id": self.agent_id, "state_file": self.state_file}))
                    return state_data
            except json.JSONDecodeError as e:
                logger.error(f"Failed to decode state file {self.state_file}: {e}. Starting with empty state.",
                             event_data={"agent_id": self.agent_id, "state_file": self.state_file, "error": str(e)}))
                return {}
            except Exception as e:
                logger.error(f"Error loading state file {self.state_file}: {e}. Starting with empty state.",
                             event_data={"agent_id": self.agent_id, "state_file": self.state_file, "error": str(e)}))
                return {}
        logger.info("No existing state file found. Starting with empty state.", event_data={"agent_id": self.agent_id, "state_file": self.state_file}))
        return {}

    def save_state(self):
        os.makedirs(os.path.dirname(self.state_file), exist_ok=True)
        try:
            # Atomic write to prevent data corruption
            tmp_state_file = self.state_file + ".tmp"
            with open(tmp_state_file, 'w') as f:
                json.dump(self.state, f, indent=2)
            os.replace(tmp_state_file, self.state_file)
            logger.info("State saved successfully.", event_data={"agent_id": self.agent_id, "state_file": self.state_file}))
        except Exception as e:
            logger.error(f"Error saving state file {self.state_file}: {e}",
                         event_data={"agent_id": self.agent_id, "state_file": self.state_file, "error": str(e)}))

    def get(self, key: str, default: Any = None) -> Any:
        return self.state.get(key, default)

    def set(self, key: str, value: Any):
        self.state[key] = value

    def update(self, new_state: Dict[str, Any]):
        self.state.update(new_state)

    def delete(self, key: str):
        if key in self.state:
            del self.state[key]

    def clear(self):
        self.state = {}
        self.save_state()
        logger.info("Agent state cleared.", event_data={"agent_id": self.agent_id}))
