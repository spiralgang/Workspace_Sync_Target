
import os
from typing import Dict, Any, List, Optional

class AgentConfig:
    """Manages agent configurations, loaded from environment variables and CLI arguments."""

    def __init__(self):
        self._config = {}
        self._load_env_vars()

    def _load_env_vars(self):
        # General Agent Settings
        self._config["AGENT_NAME"] = os.getenv("AGENT_NAME", "UniversalAgent")
        self._config["AGENT_STATE_DIR"] = os.getenv("AGENT_STATE_DIR", os.path.expanduser("~/.universal_agent"))
        self._config["AGENT_LOG_LEVEL"] = os.getenv("AGENT_LOG_LEVEL", "INFO").upper()
        self._config["AGENT_INTERVAL"] = int(os.getenv("AGENT_INTERVAL", "5")) # seconds for daemon mode
        self._config["AGENT_DRY_RUN"] = os.getenv("AGENT_DRY_RUN", "1") == "1"
        self._config["AGENT_MAX_TURNS"] = int(os.getenv("AGENT_MAX_TURNS", "10"))

        # LLM Provider Settings
        self._config["LLM_PROVIDER"] = os.getenv("LLM_PROVIDER", "openai").lower()
        self._config["OPENAI_API_KEY"] = os.getenv("OPENAI_API_KEY")
        self._config["OPENAI_BASE_URL"] = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
        self._config["OPENAI_MODEL"] = os.getenv("OPENAI_MODEL", "gpt-4o")

        self._config["GEMINI_API_KEY"] = os.getenv("GEMINI_API_KEY")
        self._config["GEMINI_MODEL"] = os.getenv("GEMINI_MODEL", "gemini-pro")

        self._config["COPILOT_API_KEY"] = os.getenv("COPILOT_API_KEY") # Placeholder for Copilot integration
        self._config["COPILOT_MODEL"] = os.getenv("COPILOT_MODEL", "copilot-gpt-4")

        self._config["OLLAMA_BASE_URL"] = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
        self._config["OLLAMA_MODEL"] = os.getenv("OLLAMA_MODEL", "llama3")

        # Cache Settings
        self._config["CACHE_TTL"] = int(os.getenv("CACHE_TTL", str(3600 * 24))) # 24 hours

        # Tool Execution Settings
        self._config["TOOL_JOBS"] = int(os.getenv("TOOL_JOBS", str(os.cpu_count() or 2)))
        self._config["TOOL_TIMEOUT"] = int(os.getenv("TOOL_TIMEOUT", "600")) # 10 minutes

        # Git Settings (for Git tools)
        self._config["GITHUB_TOKEN"] = os.getenv("GITHUB_TOKEN")
        self._config["GITLAB_TOKEN"] = os.getenv("GITLAB_TOKEN")

    def get(self, key: str, default: Any = None) -> Any:
        return self._config.get(key, default)

    def set(self, key: str, value: Any):
        self._config[key] = value

    def __getattr__(self, name: str) -> Any:
        # Allow accessing config values as attributes (e.g., config.AGENT_NAME)
        if name in self._config:
            return self._config[name]
        raise AttributeError(f"'{type(self).__name__}' object has no attribute '{name}'")

    def __str__(self) -> str:
        # Return a redacted string representation for logging/debugging
        redacted_config = {k: v for k, v in self._config.items()}
        for key in ["OPENAI_API_KEY", "GEMINI_API_KEY", "COPILOT_API_KEY", "GITHUB_TOKEN", "GITLAB_TOKEN"]:
            if redacted_config.get(key):
                redacted_config[key] = "********"
        return str(redacted_config)

# Global config instance
config = AgentConfig()
