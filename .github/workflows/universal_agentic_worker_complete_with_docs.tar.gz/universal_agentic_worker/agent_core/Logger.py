
import logging
import json
import os
from datetime import datetime
from typing import Dict, Any

from agent_core.AgentConfig import config

class JsonFormatter(logging.Formatter):
    def format(self, record):
        log_record = {
            "timestamp": datetime.fromtimestamp(record.created).isoformat(),
            "level": record.levelname,
            "message": record.getMessage(),
            "name": record.name,
            "pathname": record.pathname,
            "lineno": record.lineno,
        }
        if hasattr(record, 'event_data'):
            log_record.update(record.event_data)
        return json.dumps(log_record)

def setup_logger():
    log_dir = config.AGENT_STATE_DIR
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, "trail.log")

    # Remove all existing handlers from the root logger
    for handler in logging.root.handlers[:]:
        logging.root.removeHandler(handler)

    logger = logging.getLogger("UniversalAgent")
    logger.setLevel(config.AGENT_LOG_LEVEL)

    # File handler
    file_handler = logging.FileHandler(log_file)
    file_handler.setFormatter(JsonFormatter())
    logger.addHandler(file_handler)

    # Stream handler (console output)
    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(logging.Formatter("%(levelname)s: %(message)s")) # Simpler format for console
    logger.addHandler(stream_handler)

    logger.info(json.dumps({"event": "logger_setup", "log_file": log_file, "log_level": config.AGENT_LOG_LEVEL}))
    return logger

logger = setup_logger()

# Custom logging function to easily add event_data
def log_event(level: int, message: str, event_data: Optional[Dict[str, Any]] = None):
    if event_data is None:
        event_data = {}
    logger.log(level, message, extra={'event_data': event_data})

# Expose common logging levels with event_data support
def debug(message: str, event_data: Optional[Dict[str, Any]] = None):
    log_event(logging.DEBUG, message, event_data)

def info(message: str, event_data: Optional[Dict[str, Any]] = None):
    log_event(logging.INFO, message, event_data)

def warning(message: str, event_data: Optional[Dict[str, Any]] = None):
    log_event(logging.WARNING, message, event_data)

def error(message: str, event_data: Optional[Dict[str, Any]] = None):
    log_event(logging.ERROR, message, event_data)

def critical(message: str, event_data: Optional[Dict[str, Any]] = None):
    log_event(logging.CRITICAL, message, event_data)
