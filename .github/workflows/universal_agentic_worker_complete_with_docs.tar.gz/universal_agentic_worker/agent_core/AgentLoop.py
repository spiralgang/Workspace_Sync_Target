
import time
import json
import signal
import sys
from typing import List, Dict, Any, Optional

from agent_core.AgentConfig import config
from agent_core.Logger import logger
from agent_core.StateManager import StateManager
from agent_core.CacheManager import CacheManager
from agent_core.LLMProvider import get_llm_provider, BaseLLMProvider
from agent_core.ToolRegistry import ToolRegistry, ToolExecutor

class AgentLoop:
    """Main agent loop for multi-turn LLM interactions with tool execution."""

    def __init__(self, agent_id: str, initial_prompt: str = "You are a helpful AI assistant."):
        self.agent_id = agent_id
        self.state_manager = StateManager(agent_id)
        self.cache_manager = CacheManager(agent_id)
        self.llm_provider: BaseLLMProvider = get_llm_provider()
        self.tool_registry = ToolRegistry()
        self.tool_executor = ToolExecutor(self.tool_registry, self.cache_manager)

        self.messages: List[Dict[str, Any]] = self.state_manager.get("conversation_history", [])
        if not self.messages:
            self.messages.append({"role": "system", "content": initial_prompt})

        self._setup_signal_handlers()
        logger.info("AgentLoop initialized.", event_data={
            "agent_id": self.agent_id,
            "dry_run": config.AGENT_DRY_RUN,
            "llm_provider": config.LLM_PROVIDER,
            "initial_prompt": initial_prompt
        }))

    def _setup_signal_handlers(self):
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)

    def _signal_handler(self, signum, frame):
        logger.warning(f"Signal {signum} received. Shutting down gracefully...")
        self.state_manager.save_state()
        sys.exit(0)

    def _process_llm_response(self, response: Dict[str, Any]) -> bool:
        message = response["choices"][0]["message"]
        self.messages.append(message)

        if message.get("tool_calls"):
            tool_calls = message["tool_calls"]
            logger.info("Tool calls received from LLM.", event_data={
                "agent_id": self.agent_id,
                "tool_calls_count": len(tool_calls)
            }))
            tool_results = self.tool_executor.execute_tool_calls(tool_calls)

            for result in tool_results:
                self.messages.append({
                    "tool_call_id": result["tool_name"], # In real API, this would be tool_call_id from LLM
                    "role": "tool",
                    "name": result["tool_name"],
                    "content": json.dumps(result.get("result") or result.get("error"))
                })
            return False # Continue for another LLM turn to process tool results
        else:
            logger.info("Final LLM response received.", event_data={
                "agent_id": self.agent_id,
                "content_preview": message["content"][:100]
            }))
            return True # Task completed or no more tool calls

    def run_once(self) -> str:
        """Executes a single turn of the agent loop."""
        logger.info("Starting single agent turn.", event_data={
            "agent_id": self.agent_id,
            "turn_count": len(self.messages)
        }))

        # Prepare tools for LLM provider
        llm_tools = self.llm_provider.format_tools(self.tool_registry.get_all_tool_definitions())

        # Check cache for LLM response
        llm_input_for_cache = {"messages": self.messages, "tools": llm_tools}
        llm_response = self.cache_manager.get(llm_input_for_cache)

        if llm_response:
            logger.info("LLM response from cache.", event_data={"agent_id": self.agent_id}))
        else:
            llm_response = self.llm_provider.chat_completion(self.messages, tools=llm_tools)
            self.cache_manager.set(llm_input_for_cache, llm_response)

        is_complete = self._process_llm_response(llm_response)
        self.state_manager.set("conversation_history", self.messages)
        self.state_manager.save_state()
        logger.info("Single agent turn completed.", event_data={
            "agent_id": self.agent_id,
            "is_complete": is_complete
        }))
        return self.messages[-1]["content"]

    def run_daemon(self):
        """Runs the agent in a continuous loop."""
        logger.info("Starting agent in daemon mode.", event_data={
            "agent_id": self.agent_id,
            "interval": config.AGENT_INTERVAL
        }))
        try:
            while True:
                self.run_once()
                time.sleep(config.AGENT_INTERVAL)
        except KeyboardInterrupt:
            logger.info("Daemon mode interrupted by user.", event_data={"agent_id": self.agent_id}))
        except Exception as e:
            logger.error(f"Error in daemon mode: {e}", event_data={"agent_id": self.agent_id, "error": str(e)}))
        finally:
            self.state_manager.save_state()

    def run_interactive(self):
        """Runs the agent in an interactive REPL mode."""
        logger.info("Starting agent in interactive mode.", event_data={"agent_id": self.agent_id}))
        print(f"\nAgent 
{self.agent_id}
 in interactive mode. Type 'exit' to quit.\n")
        try:
            while True:
                user_input = input("You: ")
                if user_input.lower() == 'exit':
                    break
                self.messages.append({"role": "user", "content": user_input})
                final_response_content = self.run_once()
                print(f"Agent: {final_response_content}")
                # Heuristic for mock completion, replace with actual LLM signal
                if "Task completed based on tool execution." in final_response_content or \
                   "Hello! How can I assist you?" not in final_response_content:
                    pass # Agent continues until explicit exit or task completion signal
        except KeyboardInterrupt:
            logger.info("Interactive mode interrupted by user.", event_data={"agent_id": self.agent_id}))
        except Exception as e:
            logger.error(f"Error in interactive mode: {e}", event_data={"agent_id": self.agent_id, "error": str(e)}))
        finally:
            self.state_manager.save_state()
