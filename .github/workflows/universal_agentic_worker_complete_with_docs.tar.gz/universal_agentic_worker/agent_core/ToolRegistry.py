
import os
import json
import subprocess
import shutil
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional, Callable
from concurrent.futures import ThreadPoolExecutor, as_completed

from agent_core.AgentConfig import config
from agent_core.Logger import logger
from agent_core.CacheManager import CacheManager

class BaseTool(ABC):
    """Abstract base class for all tools."""
    def __init__(self, name: str, description: str):
        self.name = name
        self.description = description

    @abstractmethod
    def execute(self, **kwargs) -> Any:
        """Executes the tool's action."""
        pass

    def to_llm_format(self) -> Dict[str, Any]:
        """Returns the tool's definition in a generic format for LLM consumption."""
        # This is a simplified representation. A real implementation would parse function signatures
        # to generate detailed JSON schema for parameters.
        return {
            "name": self.name,
            "description": self.description,
            "parameters": {"type": "object", "properties": {}} # Simplified
        }

class FileSystemTool(BaseTool):
    """Provides tools for file system operations."""
    def __init__(self):
        super().__init__(
            name="file_system_tool",
            description="Performs file system operations like read, write, delete, list, create directory, move, copy."
        )

    def read_file(self, path: str) -> str:
        """Reads the content of a file."""
        with open(path, 'r') as f:
            return f.read()

    def write_file(self, path: str, content: str) -> str:
        """Writes content to a file (overwrites if exists)."""
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'w') as f:
            f.write(content)
        return f"File '{path}' written successfully."

    def append_to_file(self, path: str, content: str) -> str:
        """Appends content to a file."""
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'a') as f:
            f.write(content)
        return f"Content appended to file '{path}'."

    def delete_file(self, path: str) -> str:
        """Deletes a file."""
        os.remove(path)
        return f"File '{path}' deleted successfully."

    def list_directory(self, path: str) -> List[str]:
        """Lists contents of a directory."""
        return os.listdir(path)

    def create_directory(self, path: str) -> str:
        """Creates a new directory."""
        os.makedirs(path, exist_ok=True)
        return f"Directory '{path}' created successfully."

    def move_file(self, source: str, destination: str) -> str:
        """Moves a file or directory."""
        shutil.move(source, destination)
        return f"Moved '{source}' to '{destination}'."

    def copy_file(self, source: str, destination: str) -> str:
        """Copies a file."""
        shutil.copy2(source, destination)
        return f"Copied '{source}' to '{destination}'."

    def execute(self, action: str, **kwargs) -> Any:
        method = getattr(self, action, None)
        if method and callable(method):
            return method(**kwargs)
        raise ValueError(f"Unknown file system action: {action}")

class ShellCommandTool(BaseTool):
    """Executes arbitrary shell commands."""
    def __init__(self):
        super().__init__(
            name="shell_command_tool",
            description="Executes an arbitrary shell command. Use with caution as it can perform destructive actions."
        )

    def execute_shell_command(self, command: str, timeout: int = 60) -> Dict[str, Any]:
        """Executes a shell command and returns its stdout, stderr, and return code."""
        if config.AGENT_DRY_RUN:
            logger.warning("Dry run: Would execute shell command.", event_data={"command": command})
            return {"stdout": "", "stderr": f"Dry run: Would execute '{command}'", "returncode": 0}

        try:
            result = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=timeout, check=True)
            logger.info("Shell command executed successfully.", event_data={
                "command": command,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "returncode": result.returncode
            }))
            return {"stdout": result.stdout, "stderr": result.stderr, "returncode": result.returncode}
        except subprocess.CalledProcessError as e:
            logger.error("Shell command failed.", event_data={
                "command": command,
                "stdout": e.stdout,
                "stderr": e.stderr,
                "returncode": e.returncode,
                "error": str(e)
            }))
            return {"stdout": e.stdout, "stderr": e.stderr, "returncode": e.returncode, "error": str(e)}
        except subprocess.TimeoutExpired as e:
            logger.error("Shell command timed out.", event_data={
                "command": command,
                "stdout": e.stdout,
                "stderr": e.stderr,
                "error": str(e)
            }))
            return {"stdout": e.stdout, "stderr": e.stderr, "returncode": 1, "error": str(e)}
        except Exception as e:
            logger.error("Error executing shell command.", event_data={
                "command": command,
                "error": str(e)
            }))
            return {"stdout": "", "stderr": str(e), "returncode": 1, "error": str(e)}

    def execute(self, command: str, timeout: int = 60) -> Dict[str, Any]:
        return self.execute_shell_command(command, timeout)

class GitTool(BaseTool):
    """Provides tools for Git operations."""
    def __init__(self):
        super().__init__(
            name="git_tool",
            description="Performs Git operations like clone, checkout, add, commit, push, create branch, create pull request."
        )

    def _run_git_command(self, cwd: str, *args) -> Dict[str, Any]:
        command = ["git"] + list(args)
        if config.AGENT_DRY_RUN:
            logger.warning("Dry run: Would execute git command.", event_data={"command": " ".join(command), "cwd": cwd})
            return {"stdout": "", "stderr": f"Dry run: Would execute '{' '.join(command)}'", "returncode": 0}

        try:
            result = subprocess.run(command, cwd=cwd, capture_output=True, text=True, check=True)
            logger.info("Git command executed successfully.", event_data={
                "command": " ".join(command),
                "cwd": cwd,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "returncode": result.returncode
            }))
            return {"stdout": result.stdout, "stderr": result.stderr, "returncode": result.returncode}
        except subprocess.CalledProcessError as e:
            logger.error("Git command failed.", event_data={
                "command": " ".join(command),
                "cwd": cwd,
                "stdout": e.stdout,
                "stderr": e.stderr,
                "returncode": e.returncode,
                "error": str(e)
            }))
            return {"stdout": e.stdout, "stderr": e.stderr, "returncode": e.returncode, "error": str(e)}
        except Exception as e:
            logger.error("Error executing git command.", event_data={
                "command": " ".join(command),
                "cwd": cwd,
                "error": str(e)
            }))
            return {"stdout": "", "stderr": str(e), "returncode": 1, "error": str(e)}

    def clone(self, repo_url: str, target_dir: str) -> Dict[str, Any]:
        """Clones a Git repository into target_dir."""
        return self._run_git_command(os.getcwd(), "clone", repo_url, target_dir)

    def checkout(self, branch_name: str, cwd: str = ".") -> Dict[str, Any]:
        """Checks out a Git branch."""
        return self._run_git_command(cwd, "checkout", branch_name)

    def add(self, files: List[str], cwd: str = ".") -> Dict[str, Any]:
        """Stages files for commit."""
        return self._run_git_command(cwd, "add", *files)

    def commit(self, message: str, cwd: str = ".") -> Dict[str, Any]:
        """Commits staged changes."""
        return self._run_git_command(cwd, "commit", "-m", message)

    def push(self, remote: str = "origin", branch: str = "main", cwd: str = ".") -> Dict[str, Any]:
        """Pushes changes to a remote repository."""
        return self._run_git_command(cwd, "push", remote, branch)

    def create_branch(self, branch_name: str, cwd: str = ".") -> Dict[str, Any]:
        """Creates a new branch."""
        return self._run_git_command(cwd, "branch", branch_name)

    def create_pull_request(self, title: str, body: str, base_branch: str = "main", head_branch: str = "main", cwd: str = ".") -> Dict[str, Any]:
        """Creates a pull request (conceptual, requires GitHub/GitLab API integration)."""
        logger.warning("GitTool.create_pull_request is conceptual. Requires GitHub/GitLab API integration.",
                       event_data={
                           "title": title,
                           "body": body,
                           "base_branch": base_branch,
                           "head_branch": head_branch
                       })
        return {"status": "mocked", "message": "PR creation not implemented, requires API integration."}

    def execute(self, action: str, **kwargs) -> Any:
        method = getattr(self, action, None)
        if method and callable(method):
            return method(**kwargs)
        raise ValueError(f"Unknown Git action: {action}")

class ExternalAPITool(BaseTool):
    """Provides a generic tool for calling external HTTP APIs."""
    def __init__(self):
        super().__init__(
            name="external_api_tool",
            description="Makes HTTP requests to external APIs (GET, POST, PUT, DELETE)."
        )

    def call_api(self, method: str, url: str, headers: Optional[Dict[str, str]] = None, body: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Makes an HTTP request to the specified URL."""
        import requests
        if config.AGENT_DRY_RUN:
            logger.warning("Dry run: Would call external API.", event_data={
                "method": method, "url": url, "headers": headers, "body": body
            })
            return {"status": "dry_run", "message": f"Dry run: Would make {method} request to {url}"}

        try:
            response = requests.request(method, url, headers=headers, json=body, timeout=config.TOOL_TIMEOUT)
            response.raise_for_status() # Raise HTTPError for bad responses (4xx or 5xx)
            logger.info("External API call successful.", event_data={
                "method": method, "url": url, "status_code": response.status_code
            }))
            return {"status_code": response.status_code, "headers": dict(response.headers), "json": response.json() if response.content else None}
        except requests.exceptions.Timeout:
            logger.error("External API call timed out.", event_data={
                "method": method, "url": url, "error": "Timeout"
            }))
            return {"error": "Timeout", "message": f"API call to {url} timed out after {config.TOOL_TIMEOUT} seconds."}
        except requests.exceptions.RequestException as e:
            logger.error("External API call failed.", event_data={
                "method": method, "url": url, "error": str(e)
            }))
            return {"error": str(e), "message": f"API call to {url} failed: {e}"}

    def execute(self, method: str, url: str, headers: Optional[Dict[str, str]] = None, body: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        return self.call_api(method, url, headers, body)

class ToolRegistry:
    """Manages the registration and lookup of all available tools."""
    def __init__(self):
        self._tools: Dict[str, BaseTool] = {}
        self._tool_methods: Dict[str, Callable] = {}
        self._register_default_tools()

    def _register_default_tools(self):
        fs_tool = FileSystemTool()
        self.register_tool_instance(fs_tool, {
            "read_file": fs_tool.read_file,
            "write_file": fs_tool.write_file,
            "append_to_file": fs_tool.append_to_file,
            "delete_file": fs_tool.delete_file,
            "list_directory": fs_tool.list_directory,
            "create_directory": fs_tool.create_directory,
            "move_file": fs_tool.move_file,
            "copy_file": fs_tool.copy_file,
        })

        shell_tool = ShellCommandTool()
        self.register_tool_instance(shell_tool, {"execute_shell_command": shell_tool.execute_shell_command})

        git_tool = GitTool()
        self.register_tool_instance(git_tool, {
            "git_clone": git_tool.clone,
            "git_checkout": git_tool.checkout,
            "git_add": git_tool.add,
            "git_commit": git_tool.commit,
            "git_push": git_tool.push,
            "git_create_branch": git_tool.create_branch,
            "git_create_pull_request": git_tool.create_pull_request,
        })

        api_tool = ExternalAPITool()
        self.register_tool_instance(api_tool, {"call_external_api": api_tool.call_api})

    def register_tool_instance(self, tool_instance: BaseTool, methods: Dict[str, Callable]):
        """Registers an instance of a BaseTool and its callable methods."""
        self._tools[tool_instance.name] = tool_instance
        for method_name, method_func in methods.items():
            self._tool_methods[method_name] = method_func
        logger.info(f"Registered tool instance: {tool_instance.name} with methods: {list(methods.keys())}")

    def register_user_tool(self, name: str, description: str, func: Callable):
        """Registers a user-provided Python function as a tool."""
        # For simplicity, we wrap the function directly. More advanced would be to create a dynamic BaseTool subclass.
        self._tool_methods[name] = func
        logger.info(f"Registered user-defined tool: {name}")

    def get_tool_method(self, name: str) -> Optional[Callable]:
        """Retrieves a callable tool method by its name."""
        return self._tool_methods.get(name)

    def get_all_tool_definitions(self) -> Dict[str, Callable]:
        """Returns a dictionary of all callable tool methods for LLM formatting."""
        return self._tool_methods

class ToolExecutor:
    """Executes tool calls, potentially in parallel, with caching and dry-run support."""
    def __init__(self, tool_registry: ToolRegistry, cache_manager: CacheManager, max_workers: int = config.TOOL_JOBS):
        self.tool_registry = tool_registry
        self.cache_manager = cache_manager
        self.executor = ThreadPoolExecutor(max_workers=max_workers)

    def _execute_single_tool(self, tool_name: str, tool_args: Dict[str, Any]) -> Dict[str, Any]:
        start_time = time.time()
        tool_method = self.tool_registry.get_tool_method(tool_name)

        if not tool_method:
            error_msg = f"Tool method '{tool_name}' not found."
            logger.error(error_msg, event_data={"tool_name": tool_name, "tool_args": tool_args}))
            return {"tool_name": tool_name, "tool_args": tool_args, "error": error_msg, "duration": time.time() - start_time}

        # Check cache before execution
        cache_key_data = {"tool_name": tool_name, "tool_args": tool_args}
        cached_result = self.cache_manager.get(cache_key_data)
        if cached_result is not None:
            logger.info("Tool cache hit.", event_data={
                "tool_name": tool_name, "tool_args": tool_args, "duration": time.time() - start_time
            }))
            return {"tool_name": tool_name, "tool_args": tool_args, "result": cached_result, "duration": time.time() - start_time}

        # Dry run check (specific tools might have their own dry-run logic)
        if config.AGENT_DRY_RUN and not isinstance(tool_method.__self__, ShellCommandTool) and not isinstance(tool_method.__self__, GitTool) and not isinstance(tool_method.__self__, ExternalAPITool):
            logger.warning("Dry run: Would execute tool.", event_data={
                "tool_name": tool_name, "tool_args": tool_args
            }))
            return {"tool_name": tool_name, "tool_args": tool_args, "result": f"Dry run: Would execute {tool_name} with {tool_args}", "duration": time.time() - start_time}

        try:
            result = tool_method(**tool_args)
            self.cache_manager.set(cache_key_data, result)
            logger.info("Tool executed successfully.", event_data={
                "tool_name": tool_name, "tool_args": tool_args, "duration": time.time() - start_time
            }))
            return {"tool_name": tool_name, "tool_args": tool_args, "result": result, "duration": time.time() - start_time}
        except Exception as e:
            error_msg = f"Error executing tool '{tool_name}': {e}"
            logger.error(error_msg, event_data={
                "tool_name": tool_name, "tool_args": tool_args, "error": str(e),
                "duration": time.time() - start_time
            }))
            return {"tool_name": tool_name, "tool_args": tool_args, "error": error_msg, "duration": time.time() - start_time}

    def execute_tool_calls(self, tool_calls: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Executes a list of tool calls, potentially in parallel."""
        futures = []
        for tc in tool_calls:
            tool_name = tc["function"]["name"]
            try:
                tool_args = json.loads(tc["function"]["arguments"])
            except json.JSONDecodeError:
                logger.error(f"Invalid JSON arguments for tool {tool_name}", event_data={
                    "tool_name": tool_name, "arguments_raw": tc["function"]["arguments"]
                }))
                futures.append(self.executor.submit(lambda: {
                    "tool_name": tool_name,
                    "error": "Invalid JSON arguments",
                    "duration": 0
                }))
                continue
            futures.append(self.executor.submit(self._execute_single_tool, tool_name, tool_args))

        results = []
        for future in as_completed(futures):
            results.append(future.result())
        return results
