#!/bin/bash
# Universal Agentic Worker - CLI Launcher
# Multi-platform launcher for easy agent execution

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# Paths
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MAIN_PY="$SCRIPT_DIR/main.py"

# Banner
print_banner() {
    echo -e "${CYAN}"
    echo "╔═══════════════════════════════════════════════════════════╗"
    echo "║   Universal Agentic Worker - CLI Launcher v1.0.0          ║"
    echo "║   Multi-turn LLM Agent with Tool Execution Capabilities   ║"
    echo "╚═══════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

# Show help
show_help() {
    echo -e "${BLUE}Usage:${NC}"
    echo "  ./launcher.sh [OPTIONS]"
    echo ""
    echo -e "${BLUE}Options:${NC}"
    echo "  --mode MODE              Operating mode: one-shot, daemon, interactive (default: interactive)"
    echo "  --agent-id ID            Unique agent identifier (default: cli_agent_001)"
    echo "  --prompt PROMPT          Initial system prompt"
    echo "  --llm-provider PROVIDER  LLM provider: openai, gemini, copilot, ollama (default: openai)"
    echo "  --llm-model MODEL        LLM model name (default: gpt-4o)"
    echo "  --dry-run                Enable dry-run mode (no destructive actions)"
    echo "  --help                   Show this help message"
    echo ""
    echo -e "${BLUE}Examples:${NC}"
    echo "  # Interactive mode with OpenAI"
    echo "  ./launcher.sh --mode interactive --llm-provider openai"
    echo ""
    echo "  # One-shot mode with specific task"
    echo "  ./launcher.sh --mode one-shot --prompt 'List all files in current directory'"
    echo ""
    echo "  # Daemon mode with Ollama"
    echo "  ./launcher.sh --mode daemon --llm-provider ollama --llm-model llama2"
}

# Check dependencies
check_dependencies() {
    echo -e "${YELLOW}[*] Checking dependencies...${NC}"
    
    if ! command -v python3 &> /dev/null; then
        echo -e "${RED}[-] Python 3 not found. Please install Python 3.8+${NC}"
        exit 1
    fi
    
    if ! python3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)" 2>/dev/null; then
        echo -e "${RED}[-] Python 3.8+ required${NC}"
        exit 1
    fi
    
    echo -e "${GREEN}[+] Python 3 found: $(python3 --version)${NC}"
}

# Install dependencies
install_deps() {
    echo -e "${YELLOW}[*] Installing Python dependencies...${NC}"
    
    if [ -f "$SCRIPT_DIR/requirements.txt" ]; then
        pip3 install -q -r "$SCRIPT_DIR/requirements.txt"
        echo -e "${GREEN}[+] Dependencies installed${NC}"
    else
        echo -e "${YELLOW}[!] requirements.txt not found, skipping dependency installation${NC}"
    fi
}

# Run agent
run_agent() {
    local cmd=(python3 "$MAIN_PY")
    
    # Add arguments
    [[ -n "$AGENT_ID" ]] && cmd+=(--agent-id "$AGENT_ID")
    [[ -n "$MODE" ]] && cmd+=(--mode "$MODE")
    [[ -n "$PROMPT" ]] && cmd+=(--prompt "$PROMPT")
    [[ -n "$LLM_PROVIDER" ]] && cmd+=(--llm-provider "$LLM_PROVIDER")
    [[ -n "$LLM_MODEL" ]] && cmd+=(--llm-model "$LLM_MODEL")
    [[ "$DRY_RUN" == "true" ]] && cmd+=(--dry-run)
    
    echo -e "${GREEN}[+] Starting agent...${NC}"
    echo -e "${CYAN}Command: ${cmd[@]}${NC}"
    echo ""
    
    # Execute
    "${cmd[@]}"
}

# Main
main() {
    print_banner
    
    # Parse arguments
    AGENT_ID="cli_agent_001"
    MODE="interactive"
    PROMPT=""
    LLM_PROVIDER="openai"
    LLM_MODEL="gpt-4o"
    DRY_RUN="false"
    
    while [[ $# -gt 0 ]]; do
        case $1 in
            --mode)
                MODE="$2"
                shift 2
                ;;
            --agent-id)
                AGENT_ID="$2"
                shift 2
                ;;
            --prompt)
                PROMPT="$2"
                shift 2
                ;;
            --llm-provider)
                LLM_PROVIDER="$2"
                shift 2
                ;;
            --llm-model)
                LLM_MODEL="$2"
                shift 2
                ;;
            --dry-run)
                DRY_RUN="true"
                shift
                ;;
            --help)
                show_help
                exit 0
                ;;
            *)
                echo -e "${RED}Unknown option: $1${NC}"
                show_help
                exit 1
                ;;
        esac
    done
    
    # Validate mode
    case $MODE in
        one-shot|daemon|interactive)
            ;;
        *)
            echo -e "${RED}Invalid mode: $MODE${NC}"
            exit 1
            ;;
    esac
    
    # Validate LLM provider
    case $LLM_PROVIDER in
        openai|gemini|copilot|ollama)
            ;;
        *)
            echo -e "${RED}Invalid LLM provider: $LLM_PROVIDER${NC}"
            exit 1
            ;;
    esac
    
    # Check and install dependencies
    check_dependencies
    install_deps
    
    # Show configuration
    echo -e "${BLUE}Configuration:${NC}"
    echo "  Agent ID:      $AGENT_ID"
    echo "  Mode:          $MODE"
    echo "  LLM Provider:  $LLM_PROVIDER"
    echo "  LLM Model:     $LLM_MODEL"
    echo "  Dry Run:       $DRY_RUN"
    [[ -n "$PROMPT" ]] && echo "  Prompt:        ${PROMPT:0:50}..."
    echo ""
    
    # Run agent
    run_agent
}

# Run main
main "$@"
