
import argparse
import os
import sys

from agent_core.AgentConfig import config
from agent_core.Logger import logger
from agent_core.AgentLoop import AgentLoop

def main():
    parser = argparse.ArgumentParser(description="Universal Agentic Worker CLI")
    parser.add_argument("--agent-id", type=str, default="default_agent",
                        help="Unique identifier for the agent instance.")
    parser.add_argument("--mode", type=str, default="interactive",
                        choices=["one-shot", "daemon", "interactive"],
                        help="Operating mode for the agent.")
    parser.add_argument("--prompt", type=str, default="You are a helpful AI assistant.",
                        help="Initial system prompt for the agent.")
    parser.add_argument("--dry-run", action="store_true",
                        help="Enable dry-run mode (no destructive actions).")
    parser.add_argument("--llm-provider", type=str, choices=["openai", "gemini", "copilot", "ollama"],
                        help="Specify the LLM provider to use.")
    parser.add_argument("--llm-model", type=str, help="Specify the LLM model to use.")
    parser.add_argument("--interval", type=int, help="Interval in seconds for daemon mode.")
    parser.add_argument("--max-turns", type=int, help="Maximum turns for one-shot mode.")

    args = parser.parse_args()

    # Override config with CLI arguments if provided
    if args.dry_run:
        config.set("AGENT_DRY_RUN", True)
    if args.llm_provider:
        config.set("LLM_PROVIDER", args.llm_provider)
    if args.llm_model:
        if args.llm_provider == "openai":
            config.set("OPENAI_MODEL", args.llm_model)
        elif args.llm_provider == "gemini":
            config.set("GEMINI_MODEL", args.llm_model)
        elif args.llm_provider == "copilot":
            config.set("COPILOT_MODEL", args.llm_model)
        elif args.llm_provider == "ollama":
            config.set("OLLAMA_MODEL", args.llm_model)
    if args.interval:
        config.set("AGENT_INTERVAL", args.interval)
    if args.max_turns:
        config.set("AGENT_MAX_TURNS", args.max_turns)

    logger.info(f"Starting agent with config: {config}")

    agent = AgentLoop(agent_id=args.agent_id, initial_prompt=args.prompt)

    if args.mode == "one-shot":
        logger.info(f"Running agent {args.agent_id} in one-shot mode.")
        for _ in range(config.AGENT_MAX_TURNS):
            response = agent.run_once()
            if "Task completed" in response: # Heuristic for task completion
                break
        logger.info(f"One-shot mode completed for agent {args.agent_id}.")
    elif args.mode == "daemon":
        logger.info(f"Running agent {args.agent_id} in daemon mode.")
        agent.run_daemon()
    elif args.mode == "interactive":
        logger.info(f"Running agent {args.agent_id} in interactive mode.")
        agent.run_interactive()

if __name__ == "__main__":
    main()
