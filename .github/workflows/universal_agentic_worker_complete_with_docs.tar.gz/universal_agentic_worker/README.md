# Universal Agentic Worker CLI

## Overview

The Universal Agentic Worker CLI is a powerful, extensible command-line interface tool designed to create and manage fully autonomous AI agents. Inspired by the Deep SSnaHke pattern, Google ADK 2.0 principles, and FSAgent concepts, this tool enables multi-turn LLM interactions with robust tool execution capabilities, persistent state management, caching, and parallel processing. It supports various LLM providers and can be integrated seamlessly into CI/CD pipelines like GitHub Actions.

## Features

-   **Agentic Core**: Implements persistent state, hash-based caching, parallel tool execution, and daemon/interactive modes.
-   **Multi-Provider LLM Support**: Pluggable architecture for integrating with:
    -   OpenAI API (GPT models)
    -   Google Gemini API
    -   GitHub Copilot (conceptual integration for free mode)
    -   Local LLMs (Ollama, LM Studio)
    -   User-provided custom API endpoints.
-   **Comprehensive Toolset**: Agents can execute a wide range of actions:
    -   **File System Operations**: Read, write, append, delete files; list, create directories; move, copy files.
    -   **Shell Command Execution**: Execute arbitrary shell commands with configurable timeouts.
    -   **Git Operations**: Clone repositories, checkout branches, add, commit, push changes, create branches, and conceptual support for creating pull requests.
    -   **External API Calls**: Generic HTTP client for interacting with any external REST API.
    -   **User-Defined Tools**: Easily register custom Python functions as tools for the agent.
-   **Persistent State Management**: Agent conversation history, active tasks, and tool outputs are saved and loaded, allowing for long-running, resilient operations.
-   **Intelligent Caching**: Reduces LLM API costs and improves performance by caching LLM responses and tool execution results with configurable TTL.
-   **Observability**: Structured JSON-lines logging for all agent activities, LLM interactions, tool dispatches, and errors.
-   **Flexible Deployment**: Run as a standalone CLI tool, in daemon mode, interactive REPL, or as a GitHub/GitLab Actions worker.
-   **Safety Features**: Dry-run mode for all potentially destructive actions, with explicit warnings and confirmations.

## Architecture

The agent is built around a modular architecture:

-   **`AgentConfig`**: Centralized configuration management.
-   **`Logger`**: Structured logging for all events.
-   **`StateManager`**: Handles persistent agent state.
-   **`CacheManager`**: Manages hash-based caching.
-   **`LLMProvider`**: Abstract layer for LLM interactions.
-   **`ToolRegistry`**: Registers and manages available tools.
-   **`ToolExecutor`**: Executes tool calls, supporting parallelism and caching.
-   **`AgentLoop`**: The core orchestration engine for multi-turn interactions.

```mermaid
graph TD
    A[User/Scheduler] --> B(CLI/GitHub Action Trigger)
    B --> C{AgentConfig}
    C --> D[AgentLoop]
    D --> E[StateManager]
    D --> F[CacheManager]
    D --> G[LLMProvider]
    D --> H[ToolExecutor]
    H --> I[ToolRegistry]
    I --> J[File System Tools]
    I --> K[Shell Tools]
    I --> L[Git Tools]
    I --> M[External API Tool]
    I --> N[User-Defined Tools]
    G --> O[OpenAI/Copilot/Local LLMs]
    H --> P[External Systems/APIs]
    D --> Q[Logger]

    subgraph Persistence
        E -- Reads/Writes --> R[state.json]
        F -- Reads/Writes --> S[cache.json]
    end

    Q -- Writes to --> T[trail.log]

    style A fill:#f9f,stroke:#333,stroke-width:2px
    style B fill:#bbf,stroke:#333,stroke-width:2px
    style C fill:#ccf,stroke:#333,stroke-width:2px
    style D fill:#cfc,stroke:#333,stroke-width:2px
    style E fill:#fcc,stroke:#333,stroke-width:2px
    style F fill:#fcf,stroke:#333,stroke-width:2px
    style G fill:#ffc,stroke:#333,stroke-width:2px
    style H fill:#cff,stroke:#333,stroke-width:2px
    style I fill:#eee,stroke:#333,stroke-width:1px
    style J fill:#eee,stroke:#333,stroke-width:1px
    style K fill:#eee,stroke:#333,stroke-width:1px
    style L fill:#eee,stroke:#333,stroke-width:1px
    style M fill:#eee,stroke:#333,stroke-width:1px
    style N fill:#eee,stroke:#333,stroke-width:1px
    style O fill:#ddd,stroke:#333,stroke-width:1px
    style P fill:#ddd,stroke:#333,stroke-width:1px
    style Q fill:#eee,stroke:#333,stroke-width:1px
    style R fill:#eee,stroke:#333,stroke-width:1px
    style S fill:#eee,stroke:#333,stroke-width:1px
    style T fill:#eee,stroke:#333,stroke-width:1px
```

## Installation

1.  **Clone the repository:**
    ```bash
    git clone https://github.com/your-username/universal-agentic-worker.git # Replace with actual repo
    cd universal-agentic-worker
    ```

2.  **Install dependencies:**
    ```bash
    pip install -r requirements.txt
    ```

3.  **Set up Environment Variables:**
    Create a `.env` file in the root directory or set environment variables directly. At a minimum, you'll need to configure your LLM provider.

    Example `.env` for OpenAI:
    ```dotenv
    LLM_PROVIDER=openai
    OPENAI_API_KEY=your_openai_api_key_here
    OPENAI_MODEL=gpt-4o
    AGENT_DRY_RUN=True # Set to False to enable destructive actions
    ```

    Example `.env` for Ollama:
    ```dotenv
    LLM_PROVIDER=ollama
    OLLAMA_BASE_URL=http://localhost:11434
    OLLAMA_MODEL=llama3
    AGENT_DRY_RUN=True
    ```

    Refer to `agent_core/AgentConfig.py` for a full list of configurable environment variables.

## Usage

### Running the CLI

```bash
python main.py --help
```

```
usage: main.py [-h] [--agent-id AGENT_ID] [--mode {one-shot,daemon,interactive}] [--prompt PROMPT] [--dry-run] [--llm-provider {openai,gemini,copilot,ollama}] [--llm-model LLM_MODEL] [--interval INTERVAL] [--max-turns MAX_TURNS]

Universal Agentic Worker CLI

options:
  -h, --help            show this help message and exit
  --agent-id AGENT_ID   Unique identifier for the agent instance.
  --mode {one-shot,daemon,interactive}
                        Operating mode for the agent.
  --prompt PROMPT       Initial system prompt for the agent.
  --dry-run             Enable dry-run mode (no destructive actions).
  --llm-provider {openai,gemini,copilot,ollama}
                        Specify the LLM provider to use.
  --llm-model LLM_MODEL
                        Specify the LLM model to use.
  --interval INTERVAL   Interval in seconds for daemon mode.
  --max-turns MAX_TURNS
                        Maximum turns for one-shot mode.
```

### Examples

#### Interactive Mode

```bash
python main.py --mode interactive --agent-id my_first_agent --prompt "You are a helpful assistant that can manage files and execute shell commands."
```

#### One-Shot Mode (with a specific task)

```bash
python main.py --mode one-shot --agent-id file_lister --prompt "List all .py files in the current directory and save their names to a file called python_files.txt." --dry-run
```

To actually execute the file operations, remove `--dry-run`.

#### Daemon Mode

```bash
python main.py --mode daemon --agent-id monitoring_agent --prompt "Monitor the /var/log directory for new error logs every 60 seconds and report any critical errors." --interval 60
```

### GitHub Actions Integration

To use the Universal Agentic Worker in GitHub Actions, you will need to:

1.  **Build and push your Docker image** to a container registry (e.g., GitHub Container Registry).
    ```bash
    docker build -t ghcr.io/your-username/universal-agentic-worker:latest .
    docker push ghcr.io/your-username/universal-agentic-worker:latest
    ```
2.  **Update the `agent_workflow.yml`** (located in `.github/workflows/agent_workflow.yml`) with your actual Docker image path.
3.  **Configure GitHub Secrets** for your LLM API keys (e.g., `OPENAI_API_KEY`, `GEMINI_API_KEY`).

Once configured, you can trigger the workflow manually via `workflow_dispatch` or on other events (e.g., `push`, `pull_request`). The agent will run within the GitHub Actions environment, leveraging its tools and logging its activities.

## Extending the Agent

### Adding Custom Tools

You can easily add your own Python functions as tools for the agent. Modify `agent_core/ToolRegistry.py` to register your custom tools. For example:

```python
# In agent_core/ToolRegistry.py

# Define your custom function
def my_custom_tool(arg1: str, arg2: int) -> str:
    """This is a custom tool that does something useful."""
    return f"Custom tool executed with {arg1} and {arg2}"

class ToolRegistry:
    # ... existing code ...

    def _register_default_tools(self):
        # ... existing default tool registrations ...

        # Register your custom tool
        self.register_user_tool("my_custom_tool", "A custom tool for demonstration.", my_custom_tool)
```

Ensure your custom tool functions have clear docstrings, as these can be used by the LLM to understand the tool's purpose and parameters.

### Adding New LLM Providers

To integrate a new LLM provider, create a new class in `agent_core/LLMProvider.py` that inherits from `BaseLLMProvider` and implements the `chat_completion` and `format_tools` methods. Then, update the `get_llm_provider` factory function to return an instance of your new provider based on the configuration.

## Development

To contribute or develop locally:

1.  Fork the repository.
2.  Create a new branch for your features or bug fixes.
3.  Install `pre-commit` hooks for code quality checks.
4.  Run tests using `pytest` (or `unittest`).

## License

This project is licensed under the MIT License - see the `LICENSE` file for details.

## References

-   [Deep SSnaHke Pattern](https://github.com/example/deep-ssnahke) (Conceptual reference)
-   [Google ADK 2.0](https://ai.google.dev/docs/adk) (Agent Development Kit)
-   [FSAgent](https://github.com/example/fsagent) (Conceptual reference)
