#!/bin/bash
# Build script for Universal Agentic Worker APK

set -e

echo "================================"
echo "Universal Agentic Worker APK Build"
echo "================================"

# Check if Docker is available
if ! command -v docker &> /dev/null; then
    echo "Docker not found. Installing dependencies locally..."
    
    # Install Java
    if ! command -v java &> /dev/null; then
        echo "Installing OpenJDK..."
        sudo apt-get update
        sudo apt-get install -y openjdk-11-jdk
    fi
    
    # Install Gradle
    if ! command -v gradle &> /dev/null; then
        echo "Installing Gradle..."
        sudo apt-get install -y gradle
    fi
    
    # Build locally
    echo "Building APK locally..."
    gradle build
else
    echo "Building APK with Docker (Alpine Linux aarch64)..."
    docker build -t universal-agentic-worker-apk:latest .
    docker run --rm -v $(pwd)/output:/output universal-agentic-worker-apk:latest
fi

echo "================================"
echo "Build Complete!"
echo "APK output: ./app/build/outputs/apk/release/"
echo "================================"
