package com.universalagent.worker;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.Handler;
import android.os.Looper;
import androidx.annotation.Nullable;
import timber.log.Timber;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * AgentService: Background service for running the Universal Agentic Worker
 */
public class AgentService extends Service {

    private ExecutorService executorService;
    private Handler mainHandler;
    private Process agentProcess;

    @Override
    public void onCreate() {
        super.onCreate();
        executorService = Executors.newSingleThreadExecutor();
        mainHandler = new Handler(Looper.getMainLooper());
        Timber.d("AgentService created");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            return START_STICKY;
        }

        String agentId = intent.getStringExtra("agent_id");
        String mode = intent.getStringExtra("mode");
        String prompt = intent.getStringExtra("prompt");
        String llmProvider = intent.getStringExtra("llm_provider");
        String llmModel = intent.getStringExtra("llm_model");
        boolean dryRun = intent.getBooleanExtra("dry_run", true);

        Timber.i("Starting agent: %s in %s mode", agentId, mode);

        executorService.execute(() -> runAgent(agentId, mode, prompt, llmProvider, llmModel, dryRun));

        return START_STICKY;
    }

    private void runAgent(String agentId, String mode, String prompt, String llmProvider, String llmModel, boolean dryRun) {
        try {
            // Build command to execute Python agent
            String pythonScript = getFilesDir().getAbsolutePath() + "/agent_main.py";
            String[] cmd = {
                "python3",
                pythonScript,
                "--agent-id", agentId,
                "--mode", mode,
                "--prompt", prompt,
                "--llm-provider", llmProvider,
                "--llm-model", llmModel
            };

            if (dryRun) {
                cmd = java.util.Arrays.copyOf(cmd, cmd.length + 1);
                cmd[cmd.length - 1] = "--dry-run";
            }

            agentProcess = Runtime.getRuntime().exec(cmd);

            // Read stdout
            BufferedReader stdout = new BufferedReader(new InputStreamReader(agentProcess.getInputStream()));
            String line;
            while ((line = stdout.readLine()) != null) {
                Timber.d("Agent stdout: %s", line);
            }

            // Read stderr
            BufferedReader stderr = new BufferedReader(new InputStreamReader(agentProcess.getErrorStream()));
            while ((line = stderr.readLine()) != null) {
                Timber.e("Agent stderr: %s", line);
            }

            int exitCode = agentProcess.waitFor();
            Timber.i("Agent process exited with code: %d", exitCode);

        } catch (Exception e) {
            Timber.e(e, "Error running agent");
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (agentProcess != null) {
            agentProcess.destroy();
        }
        executorService.shutdown();
        Timber.d("AgentService destroyed");
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
