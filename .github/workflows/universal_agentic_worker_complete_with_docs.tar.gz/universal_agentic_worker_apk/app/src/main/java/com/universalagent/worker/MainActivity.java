package com.universalagent.worker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.CheckBox;
import androidx.appcompat.app.AppCompatActivity;
import timber.log.Timber;

/**
 * MainActivity: UI for controlling the Universal Agentic Worker on Android
 */
public class MainActivity extends AppCompatActivity {

    private EditText agentIdInput;
    private Spinner modeSpinner;
    private EditText promptInput;
    private Spinner llmProviderSpinner;
    private EditText llmModelInput;
    private CheckBox dryRunCheckbox;
    private Button startButton;
    private Button stopButton;
    private TextView statusTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize Timber logging
        Timber.plant(new Timber.DebugTree());

        // UI Component initialization
        agentIdInput = findViewById(R.id.agent_id_input);
        modeSpinner = findViewById(R.id.mode_spinner);
        promptInput = findViewById(R.id.prompt_input);
        llmProviderSpinner = findViewById(R.id.llm_provider_spinner);
        llmModelInput = findViewById(R.id.llm_model_input);
        dryRunCheckbox = findViewById(R.id.dry_run_checkbox);
        startButton = findViewById(R.id.start_button);
        stopButton = findViewById(R.id.stop_button);
        statusTextView = findViewById(R.id.status_text_view);

        // Setup spinners
        ArrayAdapter<CharSequence> modeAdapter = ArrayAdapter.createFromResource(this,
                R.array.mode_array, android.R.layout.simple_spinner_item);
        modeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        modeSpinner.setAdapter(modeAdapter);

        ArrayAdapter<CharSequence> llmAdapter = ArrayAdapter.createFromResource(this,
                R.array.llm_provider_array, android.R.layout.simple_spinner_item);
        llmAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        llmProviderSpinner.setAdapter(llmAdapter);

        // Start button listener
        startButton.setOnClickListener(v -> startAgent());

        // Stop button listener
        stopButton.setOnClickListener(v -> stopAgent());

        Timber.d("MainActivity initialized");
    }

    private void startAgent() {
        String agentId = agentIdInput.getText().toString();
        String mode = modeSpinner.getSelectedItem().toString();
        String prompt = promptInput.getText().toString();
        String llmProvider = llmProviderSpinner.getSelectedItem().toString();
        String llmModel = llmModelInput.getText().toString();
        boolean dryRun = dryRunCheckbox.isChecked();

        if (agentId.isEmpty()) {
            statusTextView.setText("Error: Agent ID cannot be empty");
            return;
        }

        Intent serviceIntent = new Intent(this, AgentService.class);
        serviceIntent.putExtra("agent_id", agentId);
        serviceIntent.putExtra("mode", mode);
        serviceIntent.putExtra("prompt", prompt);
        serviceIntent.putExtra("llm_provider", llmProvider);
        serviceIntent.putExtra("llm_model", llmModel);
        serviceIntent.putExtra("dry_run", dryRun);

        startService(serviceIntent);
        statusTextView.setText("Agent started: " + agentId);
        Timber.i("Agent started with ID: %s", agentId);
    }

    private void stopAgent() {
        Intent serviceIntent = new Intent(this, AgentService.class);
        stopService(serviceIntent);
        statusTextView.setText("Agent stopped");
        Timber.i("Agent stopped");
    }
}
